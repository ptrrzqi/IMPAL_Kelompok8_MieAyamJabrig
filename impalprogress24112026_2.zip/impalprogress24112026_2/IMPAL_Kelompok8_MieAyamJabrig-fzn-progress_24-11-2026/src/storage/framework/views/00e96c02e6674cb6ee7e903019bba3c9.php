<?php $__env->startSection('title', $tugas->judul_tugas); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb small mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-danger">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('matakuliah.show', $mk)); ?>" class="text-danger"><?php echo e($mk->kode_mk); ?></a></li>
        <li class="breadcrumb-item active">Minggu <?php echo e($tugas->minggu_ke); ?></li>
    </ol>
</nav>

<div class="row g-4">
    
    <div class="col-lg-<?php echo e($canManage ? '12' : '7'); ?>">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div>
                        <span class="badge bg-warning-subtle text-warning-emphasis mb-2">Tugas &bull; <?php echo e($tugas->status_label); ?></span>
                        <h4 class="fw-bold"><?php echo e($tugas->judul_tugas); ?></h4>
                    </div>
                    <?php if($canManage): ?>
                        <form method="POST" action="<?php echo e(route('tugas.destroy', $tugas)); ?>" onsubmit="return confirm('Hapus tugas ini beserta semua pengumpulannya?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger rounded-pill">Hapus Tugas</button>
                        </form>
                    <?php endif; ?>
                </div>
                <table class="table table-sm small mt-2 mb-3" style="max-width: 480px;">
                    <tr><th class="text-muted fw-normal">Dibuka</th><td><?php echo e($tugas->waktu_buka->translatedFormat('l, d F Y H:i')); ?></td></tr>
                    <tr><th class="text-muted fw-normal">Deadline</th><td class="fw-semibold"><?php echo e($tugas->deadline->translatedFormat('l, d F Y H:i')); ?></td></tr>
                    <tr><th class="text-muted fw-normal">Sisa waktu</th><td><?php echo e($tugas->isLewatDeadline() ? 'Sudah lewat' : $tugas->deadline->diffForHumans()); ?></td></tr>
                </table>
                <p style="white-space: pre-line;"><?php echo e($tugas->deskripsi); ?></p>
                <?php if($tugas->file_lampiran): ?>
                    <a href="<?php echo e(route('tugas.lampiran', $tugas)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill">Unduh Lampiran: <?php echo e($tugas->nama_lampiran); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if (! ($canManage)): ?>
        
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Status Pengumpulan</h6>
                    <?php if($submission): ?>
                        <table class="table table-sm small">
                            <tr><th class="text-muted fw-normal">Status</th><td><span class="badge bg-success-subtle text-success">Sudah dikumpulkan</span>
                                <?php if($submission->isTerlambat()): ?><span class="badge bg-danger-subtle text-danger">Terlambat</span><?php endif; ?></td></tr>
                            <tr><th class="text-muted fw-normal">Waktu</th><td><?php echo e($submission->waktu_kumpul->translatedFormat('d M Y, H:i')); ?></td></tr>
                            <tr><th class="text-muted fw-normal">File</th><td><a href="<?php echo e(route('pengumpulan.download', $submission)); ?>" class="text-danger"><?php echo e($submission->nama_file); ?></a></td></tr>
                            <tr><th class="text-muted fw-normal">Nilai</th><td class="fw-bold"><?php echo e(is_null($submission->nilai) ? 'Belum dinilai' : rtrim(rtrim($submission->nilai, '0'), '.') . ' / 100'); ?></td></tr>
                            <?php if($submission->feedback): ?>
                                <tr><th class="text-muted fw-normal">Feedback</th><td><?php echo e($submission->feedback); ?></td></tr>
                            <?php endif; ?>
                        </table>
                    <?php else: ?>
                        <p class="text-muted small">Anda belum mengumpulkan tugas ini.</p>
                    <?php endif; ?>

                    <?php if(Auth::user()->isMahasiswa() && ! $tugas->isBelumDibuka() && ! $tugas->isLewatDeadline() && is_null($submission?->nilai)): ?>
                        <form method="POST" action="<?php echo e(route('pengumpulan.store', $tugas)); ?>" enctype="multipart/form-data" class="mt-3">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label class="form-label small fw-semibold"><?php echo e($submission ? 'Ganti file tugas' : 'File tugas'); ?> (maks. 50 MB)</label>
                                <input type="file" name="file" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Catatan (opsional)</label>
                                <textarea name="catatan" class="form-control" rows="2"><?php echo e($submission?->catatan); ?></textarea>
                            </div>
                            <button class="btn btn-danger w-100 rounded-pill fw-semibold"><?php echo e($submission ? 'Perbarui Submission' : 'Add Submission'); ?></button>
                        </form>
                    <?php elseif($tugas->isBelumDibuka()): ?>
                        <div class="alert alert-secondary small mb-0">Tugas belum dibuka.</div>
                    <?php elseif($tugas->isLewatDeadline() && ! $submission): ?>
                        <div class="alert alert-danger small mb-0">Batas waktu pengumpulan sudah lewat.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Pengumpulan Mahasiswa (<?php echo e($daftar->whereNotNull('pengumpulan')->count()); ?>/<?php echo e($daftar->count()); ?>)</h6>
                    <div class="table-responsive">
                        <table class="table align-middle small">
                            <thead><tr><th>Mahasiswa</th><th>Status</th><th>File</th><th style="width: 360px;">Nilai & Feedback</th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $p = $row['pengumpulan']; ?>
                                <tr>
                                    <td><?php echo e($row['mahasiswa']->name); ?><br><span class="text-muted"><?php echo e($row['mahasiswa']->username); ?></span></td>
                                    <td>
                                        <?php if($p): ?>
                                            <span class="badge bg-success-subtle text-success">Dikumpulkan</span>
                                            <?php if($p->isTerlambat()): ?><span class="badge bg-danger-subtle text-danger">Terlambat</span><?php endif; ?>
                                            <div class="text-muted"><?php echo e($p->waktu_kumpul->translatedFormat('d M Y, H:i')); ?></div>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary">Belum</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php if($p): ?><a href="<?php echo e(route('pengumpulan.download', $p)); ?>" class="text-danger"><?php echo e($p->nama_file); ?></a><?php else: ?> - <?php endif; ?></td>
                                    <td>
                                        <?php if($p): ?>
                                            <form method="POST" action="<?php echo e(route('pengumpulan.nilai', $p)); ?>" class="d-flex gap-2">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <input type="number" name="nilai" min="0" max="100" step="0.01" class="form-control form-control-sm" style="width: 80px;" value="<?php echo e($p->nilai); ?>" placeholder="0-100" required>
                                                <input type="text" name="feedback" class="form-control form-control-sm" value="<?php echo e($p->feedback); ?>" placeholder="Feedback">
                                                <button class="btn btn-sm btn-danger">Simpan</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center text-muted">Belum ada mahasiswa terdaftar.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUGASTELU\SMST5\IMPAL\impalprogress24112026\IMPAL_Kelompok8_MieAyamJabrig-fzn-progress_24-11-2026\src\resources\views/tugas/show.blade.php ENDPATH**/ ?>