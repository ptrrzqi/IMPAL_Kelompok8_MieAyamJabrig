<?php $__env->startSection('title', $mataKuliah->nama_mk); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb small mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-danger">Dashboard</a></li>
        <li class="breadcrumb-item active"><?php echo e($mataKuliah->kode_mk); ?></li>
    </ol>
</nav>


<div class="p-4 rounded-4 text-white shadow-sm mb-4" style="background: linear-gradient(135deg, <?php echo e($mataKuliah->warna); ?> 0%, #18212f 100%);">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-3">
        <div>
            <span class="badge bg-white text-dark rounded-pill mb-2"><?php echo e($mataKuliah->kode_mk); ?> &bull; <?php echo e($mataKuliah->semester); ?></span>
            <h2 class="fw-bold mb-1"><?php echo e($mataKuliah->nama_mk); ?></h2>
            <div class="small opacity-75">Dosen Pengampu: <?php echo e($mataKuliah->dosen->name ?? '-'); ?></div>
            <?php if($mataKuliah->deskripsi): ?>
                <p class="mb-0 mt-2 small" style="max-width: 720px;"><?php echo e($mataKuliah->deskripsi); ?></p>
            <?php endif; ?>
        </div>
        <div class="text-md-end">
            <?php if(! is_null($progress)): ?>
                <div class="small opacity-75">Progress Anda</div>
                <div class="display-6 fw-bold"><?php echo e($progress); ?>%</div>
            <?php endif; ?>
            <?php if($canManage): ?>
                <div class="d-flex gap-2 mt-2 justify-content-md-end">
                    <button class="btn btn-light btn-sm rounded-pill fw-semibold" data-bs-toggle="modal" data-bs-target="#modalMateri">+ Tambah Materi</button>
                    <button class="btn btn-outline-light btn-sm rounded-pill fw-semibold" data-bs-toggle="modal" data-bs-target="#modalTugas">+ Tambah Tugas</button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4">
    
    <div class="<?php echo e($canManage ? 'col-lg-8' : 'col-12'); ?>">
        <?php $__empty_1 = true; $__currentLoopData = $minggu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card border-0 shadow-sm rounded-4 mb-3">
                <div class="card-header bg-white border-0 pt-3 px-4">
                    <h6 class="fw-bold mb-0">Minggu <?php echo e($m); ?></h6>
                </div>
                <div class="card-body px-4 pt-2">
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $mataKuliah->materi->where('minggu_ke', $m); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item px-0 d-flex justify-content-between align-items-center gap-2">
                                <div>
                                    <span class="badge bg-primary-subtle text-primary me-2">Materi</span>
                                    <span class="fw-semibold"><?php echo e($materi->judul_materi); ?></span>
                                    <?php if($materi->deskripsi): ?><div class="text-muted small ms-1"><?php echo e($materi->deskripsi); ?></div><?php endif; ?>
                                </div>
                                <div class="d-flex gap-2 flex-shrink-0">
                                    <?php if($materi->file_path): ?>
                                        <a href="<?php echo e(route('materi.download', $materi)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill">Unduh</a>
                                    <?php endif; ?>
                                    <?php if($canManage): ?>
                                        <form method="POST" action="<?php echo e(route('materi.destroy', $materi)); ?>" onsubmit="return confirm('Hapus materi ini?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger rounded-pill">Hapus</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $tugas->where('minggu_ke', $m); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sub = $t->pengumpulan->first(); ?>
                            <li class="list-group-item px-0 d-flex justify-content-between align-items-center gap-2">
                                <div>
                                    <span class="badge bg-warning-subtle text-warning-emphasis me-2">Tugas</span>
                                    <a href="<?php echo e(route('tugas.show', $t)); ?>" class="fw-semibold text-dark"><?php echo e($t->judul_tugas); ?></a>
                                    <div class="text-muted small ms-1">
                                        Deadline: <?php echo e($t->deadline->translatedFormat('d M Y, H:i')); ?> &bull; <?php echo e($t->status_label); ?>

                                    </div>
                                </div>
                                <div class="flex-shrink-0">
                                    <?php if($canManage): ?>
                                        <span class="badge bg-light text-dark border"><?php echo e($t->pengumpulan_count); ?>/<?php echo e($mahasiswa->count()); ?> terkumpul</span>
                                    <?php elseif($sub): ?>
                                        <span class="badge bg-success-subtle text-success">
                                            <?php echo e(is_null($sub->nilai) ? 'Sudah dikumpulkan' : 'Nilai: ' . rtrim(rtrim($sub->nilai, '0'), '.')); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary">Belum dikumpulkan</span>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center text-muted">Belum ada materi atau tugas pada mata kuliah ini.</div>
        <?php endif; ?>
    </div>

    <?php if($canManage): ?>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Peserta (<?php echo e($mahasiswa->count()); ?> mahasiswa)</h6>
                    <ul class="list-unstyled small mb-0">
                        <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="d-flex justify-content-between py-2 border-bottom">
                                <span><?php echo e($mhs->name); ?><br><span class="text-muted"><?php echo e($mhs->username); ?></span></span>
                                <span class="fw-semibold"><?php echo e($mhs->pivot->progress); ?>%</span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="text-muted">Belum ada peserta.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php if($canManage): ?>
<?php $__env->startSection('modals'); ?>

<div class="modal fade" id="modalMateri" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" method="POST" action="<?php echo e(route('materi.store', $mataKuliah)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-header"><h5 class="modal-title fw-bold">Tambah Materi</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-3"><label class="form-label">Minggu ke-</label><input type="number" name="minggu_ke" min="1" max="16" class="form-control" value="<?php echo e(($minggu->max() ?? 0) + 1); ?>" required></div>
                <div class="mb-3"><label class="form-label">Judul Materi</label><input type="text" name="judul_materi" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="2"></textarea></div>
                <div class="mb-1"><label class="form-label">File (PDF/PPT/DOC/ZIP, maks. 50 MB)</label><input type="file" name="file" class="form-control" required></div>
            </div>
            <div class="modal-footer"><button class="btn btn-danger rounded-pill px-4">Simpan Materi</button></div>
        </form>
    </div>
</div>


<div class="modal fade" id="modalTugas" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" method="POST" action="<?php echo e(route('tugas.store', $mataKuliah)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-header"><h5 class="modal-title fw-bold">Tambah Tugas</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-3"><label class="form-label">Minggu ke-</label><input type="number" name="minggu_ke" min="1" max="16" class="form-control" value="<?php echo e(($minggu->max() ?? 0) + 1); ?>" required></div>
                <div class="mb-3"><label class="form-label">Judul Tugas</label><input type="text" name="judul_tugas" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="3"></textarea></div>
                <div class="row g-2 mb-3">
                    <div class="col"><label class="form-label">Dibuka</label><input type="datetime-local" name="waktu_buka" class="form-control" value="<?php echo e(now()->format('Y-m-d\TH:i')); ?>" required></div>
                    <div class="col"><label class="form-label">Deadline</label><input type="datetime-local" name="deadline" class="form-control" value="<?php echo e(now()->addWeek()->format('Y-m-d\TH:i')); ?>" required></div>
                </div>
                <div class="mb-1"><label class="form-label">Lampiran (opsional)</label><input type="file" name="lampiran" class="form-control"></div>
            </div>
            <div class="modal-footer"><button class="btn btn-danger rounded-pill px-4">Simpan Tugas</button></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUGASTELU\SMST5\IMPAL\impalprogress24112026\IMPAL_Kelompok8_MieAyamJabrig-fzn-progress_24-11-2026\src\resources\views/matakuliah/show.blade.php ENDPATH**/ ?>