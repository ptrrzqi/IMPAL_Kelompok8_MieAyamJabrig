
<div class="col-12 col-lg-8" id="mata-kuliah">
    <div class="card border-0 shadow-sm rounded-4 h-100">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0" style="color: #1e293b;">
                    <?php echo e($user->isDosen() ? 'Mata Kuliah yang Diampu' : ($user->isAdmin() ? 'Semua Mata Kuliah' : 'Course Overview')); ?>

                </h5>
                <span class="badge text-secondary border bg-light small rounded-pill"><?php echo e($courses->count()); ?> mata kuliah</span>
            </div>

            <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="row g-2 mb-3">
                <div class="col-12">
                    <input type="search" name="q" value="<?php echo e($q); ?>" class="form-control" placeholder="Cari nama atau kode mata kuliah...">
                </div>
                <div class="col-6">
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="semua" <?php if($status === 'semua'): echo 'selected'; endif; ?>>Semua status</option>
                        <option value="aktif" <?php if($status === 'aktif'): echo 'selected'; endif; ?>>Sedang berjalan</option>
                        <option value="selesai" <?php if($status === 'selesai'): echo 'selected'; endif; ?>>Selesai</option>
                    </select>
                </div>
                <div class="col-6">
                    <select name="sort" class="form-select" onchange="this.form.submit()">
                        <option value="nama_asc" <?php if($sort === 'nama_asc'): echo 'selected'; endif; ?>>Nama A-Z</option>
                        <option value="nama_desc" <?php if($sort === 'nama_desc'): echo 'selected'; endif; ?>>Nama Z-A</option>
                        <option value="kode" <?php if($sort === 'kode'): echo 'selected'; endif; ?>>Kode MK</option>
                    </select>
                </div>
            </form>

            <div class="d-flex flex-column gap-3">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $selesai = $user->isMahasiswa() ? $course->status_course === 'selesai' : ! $course->status_aktif;
                    ?>
                    <a href="<?php echo e(route('matakuliah.show', $course)); ?>" class="card border border-light-subtle rounded-3 p-3 text-decoration-none hover-shadow">
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
                            <div class="d-flex align-items-center gap-3">
                                <div class="rounded-3 d-flex align-items-center justify-content-center text-white fw-bold flex-shrink-0"
                                     style="width: 48px; height: 48px; background-color: <?php echo e($course->warna); ?>; font-size: 0.75rem;">
                                    <?php echo e(substr($course->kode_mk, 0, 3)); ?>

                                </div>
                                <div>
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        <span class="badge bg-secondary-subtle text-secondary rounded-pill" style="font-size: 0.7rem;"><?php echo e($course->kode_mk); ?></span>
                                        <span class="text-muted" style="font-size: 0.75rem;"><?php echo e($course->semester); ?></span>
                                        <?php if($selesai): ?>
                                            <span class="badge bg-success-subtle text-success rounded-pill" style="font-size: 0.7rem;">Selesai</span>
                                        <?php endif; ?>
                                    </div>
                                    <h6 class="fw-bold mb-1 mt-1 text-dark"><?php echo e($course->nama_mk); ?></h6>
                                    <div class="text-muted small">
                                        Dosen: <?php echo e($course->dosen->name ?? '-'); ?> &bull;
                                        <?php echo e($course->materi_count); ?> materi &bull; <?php echo e($course->tugas_count); ?> tugas
                                        <?php if (! ($user->isMahasiswa())): ?> &bull; <?php echo e($course->mahasiswa_count); ?> mahasiswa <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($user->isMahasiswa()): ?>
                                <div class="text-md-end pt-2 pt-md-0" style="min-width: 140px;">
                                    <div class="d-flex justify-content-between small text-muted mb-1">
                                        <span>Progress</span>
                                        <span class="fw-bold text-dark"><?php echo e($course->progress); ?>%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar" role="progressbar" style="width: <?php echo e($course->progress); ?>%; background-color: <?php echo e($course->warna); ?>;"></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if($totalTerdaftar === 0): ?>
                        
                        <div class="text-center py-5">
                            <div class="fs-1 mb-2">&#128276;</div>
                            <h6 class="fw-bold">Tidak Terdaftar</h6>
                            <p class="text-muted small mb-0">Anda belum terdaftar di mata kuliah manapun.</p>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">Tidak ada mata kuliah yang cocok dengan pencarian/filter.</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\TUGASTELU\SMST5\IMPAL\impalprogress24112026\IMPAL_Kelompok8_MieAyamJabrig-fzn-progress_24-11-2026\src\resources\views/dashboard/_courses.blade.php ENDPATH**/ ?>