<?php $__env->startSection('title', 'Tidak Terdaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-6">
        <div class="card border-0 shadow-sm rounded-4 text-center p-5">
            <div class="fs-1 mb-3">&#128276;</div>
            <h4 class="fw-bold">Tidak Terdaftar</h4>
            <p class="text-muted">
                Anda belum terdaftar pada mata kuliah <strong><?php echo e($mataKuliah->kode_mk); ?> - <?php echo e($mataKuliah->nama_mk); ?></strong>,
                sehingga materi dan tugas tidak dapat diakses.
            </p>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-danger rounded-pill px-4">Kembali ke Course Overview</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TUGASTELU\SMST5\IMPAL\impalprogress24112026\IMPAL_Kelompok8_MieAyamJabrig-fzn-progress_24-11-2026\src\resources\views/matakuliah/tidak-terdaftar.blade.php ENDPATH**/ ?>